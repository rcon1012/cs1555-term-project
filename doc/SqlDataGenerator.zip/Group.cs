﻿namespace SqlDataGenerator {
    public class Group {
        public Group(int id) {
            this.group_id = id;
            this.name = RandomName();
            int useNullDesc = Util.rand.Next(3);
            if(useNullDesc == 0) {
                this._description = null;
            } else {
                this._description = "A group for " + this.name;
            }
            this.capacity = 0;
        }

        public int group_id { get; }
        public string name { get; }

        private string _description;
        public string description {
            get {
                if(_description == null) {
                    return "NULL";
                } else {
                    return $"'{_description}'";
                }
            }
        }

        public int capacity { get; }

        private string RandomName() {
            return "Group" + Util.rand.Next(1000000);
        }
    }
}
